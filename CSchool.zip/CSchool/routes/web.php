<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/departments', function () {
    return view('departments');
});
Route::get('/results', function () {
    return view('results');
});
Route::get('/events', function () {
    return view('events');
});
Route::get('/gallery', function () {
    return view('gallery');
});
Route::get('/intakes', function () {
    return view('intakes');
});
Route::get('/intakes', function () {
    return view('intakes');
});
Route::get('/contacts', function () {
    return view('contacts');
});
Route::get('/mweu', function () {
    return view('auth.register');
});
Route::resource('/send', 'SendsController');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
