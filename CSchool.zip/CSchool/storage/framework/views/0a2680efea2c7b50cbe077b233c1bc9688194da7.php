<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h1 class="text-right">Hello <?php echo e(Auth::user()->name); ?></h1>
                </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($request->id >= 1): ?>
                    <h5 class="text-muted">Kindly respond to the following request(s).</h5>
                    <?php else: ?>
                    <h5 class="text-muted">You currently have no request.</h5>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <hr>
                    <ul class="list-group">
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item list-group-item-info"><h5><a href=""><?php echo e($request->category); ?> Issue</a></h5>
                                <p class="bg-light" style="padding: 10px; border-radius: 5px"><?php echo e($request->question); ?>

                                <span class="badge badge-pill badge-info float-right"><?php echo e($request->email); ?></span></p>
                                <span class="float-right">
                                <form action="/send/<?php echo e($request->id); ?>" class="pull-right" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <button type="submit" style="border: none"><i class="fa fa-trash-o fa-2x" onclick="conf();"></i></button>
                                </form>
                                </span>
                                <span class="badge badge-pill badge-info float-right"><?php echo e($request->name); ?></span>
                                <span class="badge badge-pill badge-info float-left"><?php echo e($request->created_at->diffForhumans()); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>