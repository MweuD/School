function conf() {
	var retVal = confirm("Do you want to continue ?");
	if( retVal == true ){
	return true;
	}else{
	return false;
	} 
}