<?php

namespace App\Http\Controllers;

use App\Send;
use Illuminate\Http\Request;

class SendsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('send');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $send=new Send;
        $send->name=$request->name;
        $send->email=$request->email;
        $send->category=$request->category;
        $send->question=$request->question;
        $this->validate($request, [
            'name'=>'min:1|required|max:16',
            'email'=>'min:8|required|email|max:24',
            'category'=>'min:1|required',
            'question'=>'min:10|required',
        ]);
        $send->save();
        return redirect('/send')->with('mess', 'Request sent successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Send  $send
     * @return \Illuminate\Http\Response
     */
    public function show(Send $send)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Send  $send
     * @return \Illuminate\Http\Response
     */
    public function edit(Send $send)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Send  $send
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Send $send)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Send  $send
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $send=Send::find($id);
        $send->delete();
        return redirect('/home');
    }
}
