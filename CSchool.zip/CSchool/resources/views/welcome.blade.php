<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <script src="{{ asset('js/app.js') }}" defer></script>
    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('font/css/font-awesome.min.css') }}">
    <!-- Start WOWSlider.com HEAD section -->
    <link rel="stylesheet" type="text/css" href="engine1/style.css" />
    <script type="text/javascript" src="engine1/jquery.js"></script>
    <!-- End WOWSlider.com HEAD section -->
    <title>THE COUNTY SCHOOL</title>
  </head>
  <body>
    <div class="container-fluid" id="up">
        <div class="row" id="top">
            <div class="col-md-12">
                <img src="images/logo1.png" alt="" width="100%" height="55%">
            </div>
        </div>
        <div class="row" id="miangeni">
            <div class="col-md-4 mx-auto text-center">
                <img src="images/miangeni.jpg" alt="" height="90%">
            </div>
        </div>
        <div class="row" style="background: #5F9EA0; margin-top: -14px">
            <div class="col-md-4 mx-auto text-center" id="make">
                <img src="{{ asset('images/bg_white_arrow.png') }}" height="28px" alt="" style="background: #5F9EA0">
            </div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: #5F9EA0; color: black;">
        <a href="" class="navbar-brand" id="brand">THE COUNTY SCHOOL</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".collapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a href="/" class="nav-link"><i class="fa fa-home"></i> HOME</a>
                </li>
                <li class="nav-item">
                    <a href="/results" class="nav-link"><i class="fa fa-paperclip"></i> KCPE RESULTS</a>
                </li>
                <li class="nav-item">
                    <a href="/events" class="nav-link"><i class="fa fa-list"></i> EVENTS</a>
                </li>
                <li class="nav-item">
                    <a href="/departments" class="nav-link"><i class="fa fa-newspaper-o"></i> DEPARTMENTS</a>
                </li>
                <li class="nav-item">
                    <a href="/gallery" class="nav-link"><i class="fa fa-photo"></i> GALLERY</a>
                </li>
                <li class="nav-item">
                    <a href="/intakes" class="nav-link"><i class="fa fa-sign-in"></i> OUR INTAKES</a>
                </li>
                <li class="nav-item">
                    <a href="/contacts" class="nav-link"><i class="fa fa-phone"></i> CONTACT</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container-fluid" style="width: 90%">
        <div class="row mx-auto">
            <div class="col-md-12" style="padding: 1px 1px 1px 0px">
                <div id="two">
                    <h2 class="text-center" id="wel">WELCOME TO THE COUNTY SCHOOL</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <!-- Start WOWSlider.com BODY section -->
                <div id="wowslider-container1">
                <div class="ws_images"><ul>
                    <li><img src="data1/images/14.jpg" alt="14" title="THE COUNTY SCHOOL" id="wows1_0"/></li>
                    <li><img src="data1/images/15.png" alt="15" title="THE COUNTY SCHOOL" id="wows1_1"/></li>
                    <li><img src="data1/images/16.jpg" alt="16" title="THE COUNTY SCHOOL" id="wows1_2"/></li>
                    <li><img src="data1/images/17.jpg" alt="17" title="THE COUNTY SCHOOL" id="wows1_3"/></li>
                    <li><img src="data1/images/18.png" alt="18" title="THE COUNTY SCHOOL" id="wows1_4"/></li>
                    <li><img src="data1/images/19.jpg" alt="19" title="THE COUNTY SCHOOL" id="wows1_5"/></li>
                    <li><img src="data1/images/20.jpg" alt="20" title="THE COUNTY SCHOOL" id="wows1_6"/></li>
                    <li><img src="data1/images/21.jpg" alt="21" title="THE COUNTY SCHOOL" id="wows1_7"/></li>
                    <li><a href="http://wowslider.net"><img src="data1/images/25.jpg" alt="bootstrap carousel example" title="THE COUNTY SCHOOL" id="wows1_8"/></a></li>
                    <li><img src="data1/images/34.jpg" alt="34" title="THE COUNTY SCHOOL" id="wows1_9"/></li>
                  </ul></div>
                  <div class="ws_bullets"><div>
                    <a href="#" title="14"><span><img src="data1/tooltips/14.jpg" alt="14"/>1</span></a>
                    <a href="#" title="15"><span><img src="data1/tooltips/15.png" alt="15"/>2</span></a>
                    <a href="#" title="16"><span><img src="data1/tooltips/16.jpg" alt="16"/>3</span></a>
                    <a href="#" title="17"><span><img src="data1/tooltips/17.jpg" alt="17"/>4</span></a>
                    <a href="#" title="18"><span><img src="data1/tooltips/18.png" alt="18"/>5</span></a>
                    <a href="#" title="19"><span><img src="data1/tooltips/19.jpg" alt="19"/>6</span></a>
                    <a href="#" title="20"><span><img src="data1/tooltips/20.jpg" alt="20"/>7</span></a>
                    <a href="#" title="21"><span><img src="data1/tooltips/21.jpg" alt="21"/>8</span></a>
                    <a href="#" title="25"><span><img src="data1/tooltips/25.jpg" alt="25"/>9</span></a>
                    <a href="#" title="34"><span><img src="data1/tooltips/34.jpg" alt="34"/>10</span></a>
                  </div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">javascript slider</a> by WOWSlider.com v8.8</div>
                <div class="ws_shadow"></div>
                </div>  
                <script type="text/javascript" src="engine1/wowslider.js"></script>
                <script type="text/javascript" src="engine1/script.js"></script>
                <!-- End WOWSlider.com BODY section -->
                
            </div>
          </div>

        <hr>
            <div class="row" id="info">
                <div class="col-md-3 col-sm-6 text-right">
                    <img src="{{ asset('images/2.png') }}" alt="" width="170px" height="170px" id="img1">
                </div>
                <div class="col-md-3 col-sm-6" id="about">
                    <h4 class="text-info">ABOUT THE SCHOOL</h4>
                    <p>The County School Is a mixed day and boarding Primary school based in Kenya, Makueni county, Wote subcounty: offering the 8.4.4 system for both national and international pupils. It has competent staff to give the best who are meant to pursue excellence.</p>
                </div>
                <div class="col-md-3 col-sm-6 mx-auto text-right">
                    <img src="{{ asset('images/3.png') }}" alt="" width="170px" height="170px" id="img2">
                </div>
                <div class="col-md-3 col-sm-6" id="results">
                    <h4 class="text-info">AWESOME RESULTS OF OUR PUPILS</h4>
                    <p>The County School managed to be Position ten (10) in KENYA with a meanscore of XXX.XX All pupils were able to get vacancies in various National and extra-county schools in the country. <a href="" class="">click here to download 2017 KCPE Results.</a></p>
                </div>
            </div>
            <div class="row">
            <div class="col-md-12 text-center">
                    <img src="{{ asset('images/bg_white_arrow.png') }}" height="28px" alt="" style="background: #2b4167">
            </div>
            </div>
            <div class="row mx-auto" id="motto">
                <div class="col-md-2">
                    <img src="{{ asset('images/boy.jpg') }}" alt="" class="rounded change" width="90px">
                </div>
                <div class="col-md-4">
                    <h4 class="text-white">Our Mission</h4>
                    <a href="" class="get">See results comparison for our previous years.</a>
                    <p class="text-white">Providing priceless education that will inspire perfection and performance for exellence.</p>
                </div>
                <div class="col-md-2">
                    <img src="{{ asset('images/boy.jpg') }}" alt="" class="rounded change" width="90px" >
                </div>
                <div class="col-md-4">
                    <h4 class="text-white">Our Vision</h4>
                    <a href="" class="get">See results comparison for our previous years.</a>
                    <p class="text-white">To provide very hardworking and excellent citizens who will be an asset both nationally and internationally.</p>
                </div>
                <div class="col-md-8 mx-auto text-center">
                    <h2 class="text-white">OUR MOTTO</h2>
                    <a class="btn btn-light" href="#up">Meant to pursue Excellence</a>
                </div>
            </div>
        <div class="row">
          <div class="col-md-12 mx-auto text-center">
            <img src="{{ asset('images/bg_white.png') }}" alt="" width="100%" height="30px" style="background: #2b4167">
          </div>
        </div>
      <br>
        <div class="row">
          <div class="col-md-12 mx-auto">
              <h2 class="text-center">UPCOMING EVENTS</h2>
          </div>
      </div>
      <hr>
      <br>
      <div class="row">
        <div class="col-md-1">
            <div id="outer">
              <h6 class="text-center text-white" id="months">MAY</h6>
              <div id="inner">
                <h3 class="text-center text-info">1</h3>
              </div>
            </div>
        </div>
        <div class="col-md-2">
            <p id="reduce">All pupils are requred to report back to school to resume 2018 second term,academic year on 1st May. Parents are also required to prepare their children fully for best performance.</p>
            <p id="reduce"><a href="/events">Read more <img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt=""></a></p>
        </div>
        <div class="col-md-1">
            <div id="outer">
              <h6 class="text-center text-white" id="months">AUGUST</h6>
              <div id="inner">
                <h3 class="text-center text-info">3</h3>
              </div>
            </div>
        </div>
        <div class="col-md-2">
            <p id="reduce">This will be the end of the second term. That is; The closing date. 3rd August 2018. Thanks in advance to all parents for their support.</p>
            <p id="reduce"><a href="/events">Read more <img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt=""></a></p>
        </div>
        <div class="col-md-1">
            <div id="outer">
              <h6 class="text-center text-white" id="months">AUGUST</h6>
              <div id="inner">
                <h3 class="text-center text-info">28</h3>
              </div>
            </div>
        </div>
        <div class="col-md-2">
            <p id="reduce">All pupils are requred to report back to school to resume 2018 third term of the academic year on 28th August . Parents are also required to prepare their children fully for best performance</p>
            <p id="reduce"><a href="/events">Read more <img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt=""></a></p>
        </div>
        <div class="col-md-1">
            <div id="outer">
              <h6 class="text-center text-white" id="months">OCTOBER</h6>
              <div id="inner">
                <h3 class="text-center text-info">26</h3>
              </div>
            </div>
        </div>
        <div class="col-md-2">
            <p id="reduce">This will be the end of the third term. That is; The closing date. 26th October, 2018. Thanks in advance to all parents for their support.</p>
            <p id="reduce"><a href="/events">Read more <img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt=""></a></p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 mx-auto text-center">
          <a href="/events" class="btn btn-primary btn-outline-primary" id="more">See all upcoming events</a>
        </div>
      </div>
      <br>
      <br>
      <br>
      <div class="row" id="request">
        <div class="col-md-9" id="long">
          <a href="/send" id="form" class="text-white"><h1 style="line-height: 5px"><i class="fa fa-edit fa-2x"></i>REQUEST INFORMATION</h1>
          <h6 class="text-center" style="line-height: 30px">DO YOU HAVE SOME QUESTIONS? PLEASE TALK TO US!</h6></a>
        </div>
        <div class="col-md-3" style="padding-left: 0px">
          <a href="/send"><img src="images/5.png" alt="" width="100%" class="bg-primary" height="150px" width="100%" id="arrow" style="padding: 40px"></a>
        </div>
      </div>
    </div>
    <br>  
    <br>
    <br>
    <br>
    <div class="container-fluid text-white" style="width: 100%; margin:0"> 
      <div class="row" id="last">
        <div class="col-md-12 text-center">
            <img src="{{ asset('images/bg_white_arrow.png') }}" height="28px" alt="" style="background: #2b4167" id="final">
          </div>
        <div class="col-md-3">
          <h2>CONTACT</h2>
          <div class="row">
              <div class="col-md-2">
                <i class="fa fa-map-marker fa-2x"></i>
              </div>
              <div class="col-md-10">
                <p>Located 6km from Wote town. Off Wote Nairobi Road</p>
              </div>
          </div>
          <hr class="bg-light">
          <div class="row">
              <div class="col-md-2">
                <i class="fa fa-envelope fa-2x"></i>
              </div>
              <div class="col-md-10">
                <p>thecountyschool@gmail.com</p>
              </div>
          </div>
              <hr class="bg-light">
          <div class="row">
            <div class="col-md-2">
                <i class="fa fa-phone fa-2x"></i>
              </div>
              <div class="col-md-10">
              <p> +25412558812- Office,
              <p>+254745242573- HR, +254745242573- Academic Director, +254745242573- Senior Director, +254745242573-  Director</p>
              </div>
          </div>
              
              <hr class="bg-light">
        </div>
        <div class="col-md-3">
          <h2>FORUM TOPICS</h2>
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results 2015</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results 2016</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results 2017</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results Analysis</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download Admision letter</a>
          <hr class="bg-light">
        </div>
        <div class="col-md-3">
          <h2>SOCIAL MEDIA</h2>
          <p>Our staff, parents and general public can like/follow us on various social media platforms.</p>
          <div class="col-md-12">
            <a href=""><i id="social" class="fa fa-facebook fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-twitter fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-google fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-pinterest fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-linkedin fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-instagram fa-2x"></i></a>
          </div>
        </div>
        <div class="col-md-3">
          <h2>NEWS LETTER</h2>
          <p>Kindly subscribe for all our news letters to get updated.</p>
          <form action="">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Email Address" id="sub">
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-block btn-light">Subscribe</button>
            </div>
          </form>
        </div>
        <div class="col-md-12">
          <p class="text-center text-muted">Copyright 2018 The County School. Designed by <span class="text-white">Dantech Designers Solutions (+254712558812).</span> All Rights Reserved</p>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="main.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
  </body>
</html>