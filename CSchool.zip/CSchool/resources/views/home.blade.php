@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h1 class="text-right">Hello {{ Auth::user()->name }}</h1>
                </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    @foreach ($requests as $request)
                    
                    @if ($request->id >= 1)
                    <h5 class="text-muted">Kindly respond to the following request(s).</h5>
                    @else
                    <h5 class="text-muted">You currently have no request.</h5>
                    @endif
                    @endforeach
                    
                    <hr>
                    <ul class="list-group">
                        @foreach ($requests as $request)
                            <li class="list-group-item list-group-item-info"><h5><a href="">{{ $request->category }} Issue</a></h5>
                                <p class="bg-light" style="padding: 10px; border-radius: 5px">{{ $request->question }}
                                <span class="badge badge-pill badge-info float-right">{{ $request->email }}</span></p>
                                <span class="float-right">
                                <form action="/send/{{ $request->id }}" class="pull-right" method="post">
                                    {{ csrf_field() }}
                                    {{ method_field('DELETE') }}
                                    <button type="submit" style="border: none"><i class="fa fa-trash-o fa-2x" onclick="conf();"></i></button>
                                </form>
                                </span>
                                <span class="badge badge-pill badge-info float-right">{{ $request->name }}</span>
                                <span class="badge badge-pill badge-info float-left">{{ $request->created_at->diffForhumans() }}</span>
                            </li>
                        @endforeach
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
