<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <script src="{{ asset('js/app.js') }}" defer></script>
    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('font/css/font-awesome.min.css') }}">
    <title>THE COUNTY SCHOOL</title>
  </head>
  <body>
    <div class="container-fluid" id="up">
      <div class="row" id="top">
        <div class="col-md-12">
          <img src="images/logo1.png" alt="" width="100%" height="55%">
        </div>
      </div>
      <div class="row" id="miangeni">
        <div class="col-md-4 mx-auto text-center">
          <img src="images/miangeni.jpg" alt="" height="90%">
        </div>
      </div>
      <div class="row" style="background: #5F9EA0; margin-top: -14px">
        <div class="col-md-4 mx-auto text-center" id="make">
          <img src="images/bg_white_arrow.png" height="28px" alt="" style="background: #5F9EA0">
        </div>
      </div>
    </div>
    <nav class="navbar navbar-expand-lg navbar-dark" style="background: #5F9EA0; color: black;">
      <a href="" class="navbar-brand" id="brand">THE COUNTY SCHOOL</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".collapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a href="/" class="nav-link"><i class="fa fa-home"></i> HOME</a>
          </li>
          <li class="nav-item">
            <a href="/results" class="nav-link"><i class="fa fa-paperclip"></i> KCPE RESULTS</a>
          </li>
          <li class="nav-item active">
            <a href="/events" class="nav-link"><i class="fa fa-list"></i> EVENTS</a>
          </li>
          <li class="nav-item">
            <a href="/departments" class="nav-link"><i class="fa fa-newspaper-o"></i> DEPARTMENTS</a>
          </li>
          <li class="nav-item">
            <a href="/gallery" class="nav-link"><i class="fa fa-photo"></i> GALLERY</a>
          </li>
          <li class="nav-item">
            <a href="/intakes" class="nav-link"><i class="fa fa-sign-in"></i> OUR INTAKES</a>
          </li>
          <li class="nav-item">
            <a href="/contacts" class="nav-link"><i class="fa fa-phone"></i> CONTACT</a>
          </li>
        </ul>
      </div>
    </nav>
    <div class="container-fluid" style="padding-left: 0;">
     <div class="row">
       <div class="col-md-12 mx-auto text-center" id="band">
          <img src="images/bg_white_arrow.png" height="28px" alt="" style="background: #2b4167">
       </div>
     </div> 
    </div>

    <br>  
    <br>
    <br>
    <br>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <a href="/" class="btn btn-primary"><i class="fa fa-arrow-circle-left"></i>Back</a>
        </div>
        <div class="col-md-8">
            @if (session('mess'))
                    <div class="alert alert-success alert-dismissable">
                        <button class="close" data-dismiss="alert">&times;</button>
                        <p>{{ session('mess')}}</p>
                    </div>
            @endif
            <div class="card" style="padding-bottom: 30px">
                <div class="card-header">
                    <h3 class="text-info text-muted text-center">REQUEST INFORMATION</h3>
                </div>

                <div class="card-body">
                    <form method="POST" action="/send">
                        @csrf
                        <div class="row">
                            <div class="col-md-6">
                                <label for="name" class="col-form-label"><b>{{ __('Name') }}</b></label>
                                <input id="name" placeholder="Mary" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" required>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                                <label for="email" class="col-form-label"><b>{{ __('Email') }}</b></label>
                                <input id="email" placeholder="you@example.com" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" required>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                                <label for="name" class="col-form-label"><b>{{ __('Category') }}</b></label>
                                <select name="category" id="" class="form-control">
                                    <option value="Personal">Personal</option>
                                    <option value="Academic">Academic</option>
                                    <option value="Enquiry">Enquiry</option>
                                </select>

                                @if ($errors->has('category'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('category') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-6">
                                <label for="question" class="col-form-label"><b>{{ __('Question') }}</b></label>
                                <textarea name="question" id="" cols="3" rows="4" class="form-control" placeholder="Kindly assist, how do I get to your institution?..."></textarea>

                                @if ($errors->has('question'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('question') }}</strong>
                                    </span>
                                @endif
                                <br>
                                <br>
                                <button class="btn btn-info float-right" type="submit">Send Request</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<br>  
    <br>
    <br>
    <br>
    <div class="container-fluid text-white" style="width: 100%; margin:0"> 
      <div class="row" id="last">
        <div class="col-md-12 text-center">
            <img src="{{ asset('images/bg_white_arrow.png') }}" height="28px" alt="" style="background: #2b4167" id="final">
          </div>
        <div class="col-md-3">
          <h2>CONTACT</h2>
          <div class="row">
              <div class="col-md-2">
                <i class="fa fa-map-marker fa-2x"></i>
              </div>
              <div class="col-md-10">
                <p>Located 6km from Wote town. Off Wote Nairobi Road</p>
              </div>
          </div>
          <hr class="bg-light">
          <div class="row">
              <div class="col-md-2">
                <i class="fa fa-envelope fa-2x"></i>
              </div>
              <div class="col-md-10">
                <p>thecountyschool@gmail.com</p>
              </div>
          </div>
              <hr class="bg-light">
          <div class="row">
            <div class="col-md-2">
                <i class="fa fa-phone fa-2x"></i>
              </div>
              <div class="col-md-10">
              <p> +25412558812- Office,
              <p>+254745242573- HR, +254745242573- Academic Director, +254745242573- Senior Director, +254745242573-  Director</p>
              </div>
          </div>
              
              <hr class="bg-light">
        </div>
        <div class="col-md-3">
          <h2>FORUM TOPICS</h2>
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results 2015</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results 2016</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results 2017</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download KCPE Results Analysis</a>
          <hr class="bg-light">
          <a href="" id="down"><img src="{{ asset('images/bg_arrow_blue_dark.png') }}" alt="">Download Admision letter</a>
          <hr class="bg-light">
        </div>
        <div class="col-md-3">
          <h2>SOCIAL MEDIA</h2>
          <p>Our staff, parents and general public can like/follow us on various social media platforms.</p>
          <div class="col-md-12">
            <a href=""><i id="social" class="fa fa-facebook fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-twitter fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-google fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-pinterest fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-linkedin fa-2x"></i></a>&nbsp;
            <a href=""><i id="social" class="fa fa-instagram fa-2x"></i></a>
          </div>
        </div>
        <div class="col-md-3">
          <h2>NEWS LETTER</h2>
          <p>Kindly subscribe for all our news letters to get updated.</p>
          <form action="">
            <div class="form-group">
              <input type="text" class="form-control" placeholder="Email Address" id="sub">
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-block btn-light">Subscribe</button>
            </div>
          </form>
        </div>
        <div class="col-md-12">
          <p class="text-center text-muted">Copyright 2018 The County School. Designed by <span class="text-white">Dantech Designers Solutions (+254712558812).</span> All Rights Reserved</p>
        </div>
      </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="main.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
  </body>
</html>
